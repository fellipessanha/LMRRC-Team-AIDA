
// SYSTEM LIBS
#include <algorithm>
#include <fstream>
#include <functional>
#include <iostream>

// must include before nlohmann::json
#include <vastjson/VastJSON.hpp>

// JSON LIBS
#include <nlohmann/json.hpp>
// using json = nlohmann::json;

// optimization components for AMZ
#include "OptAMZ.hpp"

// import everything on main()
using namespace optframe;
using namespace scannerpp;
using namespace TSP_amz;
using namespace vastjson;

int
main(int argc, char* argv[])
{
   std::cout << "====== BEGIN AMAZ HISTORICAL =======" << std::endl;
   std::string dirPath = "data/model_build_inputs/";
   // =============== LOADING FILES ==============
   //
   VastJSON actual_sequences(
     new std::ifstream(dirPath+"actual_sequences.json"),
     BIG_ROOT_DICT_NO_ROOT_LIST);
   //
   // must replace "NaN" to "null"
   std::string jsonContent = TSP_amz::removeNaN(dirPath+"package_data.json");
   VastJSON package_data(jsonContent, BIG_ROOT_DICT_NO_ROOT_LIST);
   //
   // Being used to fetch routes.
   // must replace "NaN" to "null"
   jsonContent = TSP_amz::removeNaN(dirPath+"route_data.json");
   VastJSON route_data(
     new std::ifstream(dirPath+"route_data.json"),
     BIG_ROOT_DICT_NO_ROOT_LIST);
   //
   VastJSON travel_times(
     new std::ifstream(dirPath+"travel_times.json"),
     BIG_ROOT_DICT_NO_ROOT_LIST);
   //std::cout << "travel_times.size() = " << travel_times.size() << std::endl;
   //
   std::ifstream finvalid(dirPath+"invalid_sequence_scores.json");
   nlohmann::json invalid = nlohmann::json::parse(finvalid);
   std::cout << "invalid.size() = " << invalid.size() << std::endl;
   //
   int sz = route_data.size();
   std::cout << "route_data.size() = " << sz << std::endl;

   FILE* f_out = fopen("local_search_routes_hl-tw.txt", "w");

   for(auto it1 = route_data.begin(); it1 != route_data.end(); it1++) {
      std::string route_id = it1->first;
      //std::cout << "ROUTE = " << route_id << std::endl;
      //std::cout <<  it1->second << std::endl;
      pTSP.load(route_id, package_data, route_data, travel_times);
      fprintf(f_out, "%s\t", route_id.c_str());

      std::string high_low = route_data[route_id]["route_score"];
      std::cout << high_low << std::endl;
      fprintf(f_out, "%s\t", high_low.c_str());

      // =========================
      // EXECUTE LOCAL SEARCH!!
      // =========================

      std::vector<int> vr = pTSP.getRoute(route_id, actual_sequences);

      ESolutionTSP esol(vr, ev.evaluate(vr));
      esol.second.print();
      fprintf(f_out, "%f\t", esol.second.evaluation());

      EvalAMZ f_amz = fevaluate_amz(esol.first);
      f_amz.print();

      fprintf(f_out, "%f\t%f\t%d\t%f\t%d\t", 
         f_amz.e_dist,
         f_amz.e_before_tw,
         f_amz.count_before_tw,
         f_amz.e_after_tw,
         f_amz.count_after_tw
         );
      

      // =========================

      //
      vsref<LocalSearch<ESolutionTSP>> lsList;
      lsList.push_back( new FirstImprovement<ESolutionTSP>(ev, nsseq2) );

      VariableNeighborhoodDescent<ESolutionTSP> vnd(ev, lsList);

      auto status_vnd = vnd.searchFrom(esol, {1.0}); // 10 secs
      std::cout << (int)status_vnd << std::endl;

      esol.second.print(); // print evaluation
      ev.evaluate(esol.first).print(); // re-print!
      fprintf(f_out, "AFTER_FI\t%f\t", esol.second.evaluation());

      f_amz = fevaluate_amz(esol.first);
      f_amz.print();

      fprintf(f_out, "%f\t%f\t%d\t%f\t%d\n", 
         f_amz.e_dist,
         f_amz.e_before_tw,
         f_amz.count_before_tw,
         f_amz.e_after_tw,
         f_amz.count_after_tw
         );
      //
      fflush(f_out);

      // =========================
      //
      package_data.unload(route_id);
      route_data.unload(route_id);
      travel_times.unload(route_id);
      //getchar();
   }
   fclose(f_out);
   
   //
   std::cout << "FINISHED LOAD HISTORICAL!" << std::endl;

   return 0;
}
