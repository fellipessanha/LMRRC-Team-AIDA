
// SYSTEM LIBS
#include <algorithm>
#include <fstream>
#include <functional>
#include <iostream>

// must include before nlohmann::json
#include <vastjson/VastJSON.hpp>

// JSON LIBS
#include <nlohmann/json.hpp>
using json = nlohmann::json;

// optimization components for AMZ
#include "OptAMZ.hpp"

// import everything on main()
using namespace optframe;
using namespace scannerpp;
using namespace TSP_amz;
using namespace vastjson;

#include "EvalIntegration.hpp" // from 'featurescpp'
#include "classifier.c" // from 'featurescpp'

using FeatureEngPhase = classifier::FeatureEngineering::FeatureEngPhase;


class MyEvaluator final : public Evaluator<ESolutionTSP::first_type, ESolutionTSP::second_type, ESolutionTSP>
{
   using S = ESolutionTSP::first_type;
   using XEv = ESolutionTSP::second_type;
   using XSH = ESolutionTSP; // only single objective

public:

   classifier::SolutionIntegration& global;

   MyEvaluator(
      classifier::SolutionIntegration& _global
   )
   :
   global{ _global }
   {
   }

   virtual Evaluation<double> evaluate(const std::vector<int>& sol)
   {
      json jseq = pTSP.returnOutput(sol);
      classifier::features ft = global.initSequence(jseq);


      double* array_feats;
      array_feats = global.feng.featuresAs_pointer_array(ft);
      //for (int i = 0; i < 43; i++)
      //   std::cout << i << "; " << array_feats[i] << "\t";
      //std::cout << std::endl;
      // Scoring!
      double output[2];
      score(array_feats, output);

      return output[0]; // probability of being 'high' (WE THINK SO... TODO: check!)
   }

   virtual bool isMinimization() const
   {
      return false; // MAXIMIZING!
   }
};



void testRuntime(std::string routeId) {
   // THIS IS WHERE EVERYTHING HAPPENS

   // HASKELL / F# (puramente funcional!)
   // Teoria Calculo Lambda vs Maquinas de Turing (99.99999%)
   //
   srand(100001);

   classifier::SolutionIntegration global{routeId};

   pTSP.load(routeId, global.feng.package_data, global.feng.route_data, global.feng.travel_times);

   

   // generate random route
   std::vector<int> sol = *crand.generateSolution(0);

   json jseq = pTSP.returnOutput(sol);

   std::cout << "jseq: " << jseq << std::endl;

   classifier::features ft = global.initSequence(jseq);

   std::cout << ft << std::endl;

   MyEvaluator ev(global);
   ev.evaluate(sol).print();


   sref<RandGen> rg2{ new RandGen }; // heap version (safely shared)
   
   BasicInitialSearch<ESolutionTSP> initRand(crand, ev);
      //
      BasicSimulatedAnnealing<ESolutionTSP> sa(
      //_evaluator, _constructive, _neighbors, _alpha, _SAmax, _Ti, _rg
      ev,
      initRand,
      nsseqSwap,
      0.98,
      200,
      9999,
      rg2);

      auto status = sa.search(10.0); // 10.0 seconds max
      ESolutionTSP best = *status.best;
      // best solution value
      best.second.print();

   //classifier::features& feats_de_uma_rota = global.feng.checkFeatures(routeId);
   //std::cout << feats_de_uma_rota << std::endl;
}


int
main(int argc, char* argv[])
{
   std::cout << "====== BEGIN AMAZ RUNTIME =======" << std::endl;
   testRuntime("RouteID_15baae2d-bf07-4967-956a-173d4036613f");

   exit(1);
   //
   std::cout << "====== BEGIN AMAZ =======" << std::endl;
   std::string dirPath = "data/model_apply_inputs/";
   std::string jsonContent = TSP_amz::removeNaN(dirPath + "new_package_data.json");
   // =============== LOADING FILES ==============
   VastJSON new_package_data(jsonContent, BIG_ROOT_DICT_NO_ROOT_LIST);
   // std::cout << "package_data.size() = " << new_package_data.size() << std::endl;
   //
   // Being used to fetch routes.
   jsonContent = TSP_amz::removeNaN(dirPath + "new_route_data.json");
   VastJSON new_route_data(jsonContent, BIG_ROOT_DICT_NO_ROOT_LIST);
   //
   jsonContent = TSP_amz::removeNaN(dirPath + "new_travel_times.json");
   VastJSON new_travel_times(jsonContent, BIG_ROOT_DICT_NO_ROOT_LIST);
   std::cout << "new_travel_times.size() = " << new_travel_times.size() << std::endl;
   //
   std::cout << "FINISHED LOAD!" << std::endl;
   //
   // Random number generator
   // Not necessary on VNS
   sref<RandGen> rg2{ new RandGen }; // heap version (safely shared)
   //
   // writing everything in a string because of pop_back() method for the last ','
   std::string outputWriter;
   //
   /* used for benchmarking
   long t1 = ::time(0);
   std::cout << "SIZE = " << bigj.size() << std::endl;
   std::cout << "time: " << (::time(0) - t1) << " seconds" << std::endl;
   */
   //
   /* =============== FIRST RANDOM SOLUTION ==============
   std::cout << "TSP FCore AMZ example" << std::endl;
   //
   std::vector<int> sol = *crand.generateSolution(0);
   std::cout << sol << std::endl;
   //
   // evaluation value and store on ESolution pair
   ESolutionTSP esol(sol, ev.evaluate(sol));
   esol.second.print(); // print evaluation
   // ================================================
   */
   // =============== SETTING UP SEARCH ==============
   //
   std::cout << "prepping neighborhood search\n";
   vsref<LocalSearch<ESolutionTSP>> lsList;
   lsList.push_back(new FirstImprovement<ESolutionTSP>(ev, nsseqSwap));
   lsList.push_back(new FirstImprovement<ESolutionTSP>(ev, nsseq2Opt));
   lsList.push_back(new FirstImprovement<ESolutionTSP>(ev, nsseqOrOpt3));
   std::cout << "DONE!\n";
   //
   // Getting route id reference from new_route_data
   for (auto it1 = new_route_data.begin(); it1 != new_route_data.end(); it1++) {
      std::string route_id = it1->first;
      pTSP.load(route_id, new_package_data, new_route_data, new_travel_times);
      //
      // Generating first random solution
      std::vector<int> sol = *crand.generateSolution(0);
      ESolutionTSP esol(sol, ev.evaluate(sol));
      //
      VariableNeighborhoodDescent<ESolutionTSP> vnd(ev, lsList);
      vnd.setSilent();
      //
      auto status_vnd = vnd.searchFrom(esol, { 1.0 }); // 10 secs
      // std::cout << (int)status_vnd << std::endl;
      //
      esol.second.print(); // print evaluation
      outputWriter += "\"" + route_id + "\":{\"proposed\":" +
                      pTSP.returnOutput(esol.first).dump() + "},";
   }
   /*
   // =============== SIMULATED ANNEALING ==============
   for(auto it1 = new_route_data.begin(); it1 != new_route_data.end(); it1++) {
      std::string route_id = it1->first;
      // std::cout << "running simulated annealing for route " << route_id << std::endl;
      pTSP.load(route_id, new_package_data, new_route_data, new_travel_times);
      //
      // testing simulated annealing
      BasicInitialSearch<ESolutionTSP> initRand(crand, ev);
      //
      BasicSimulatedAnnealing<ESolutionTSP> sa(
      //_evaluator, _constructive, _neighbors, _alpha, _SAmax, _Ti, _rg
      ev,
      initRand,
      nsseq2,
      0.98,
      200,
      9999,
      rg2);

      auto status = sa.search(10.0); // 10.0 seconds max
      ESolutionTSP best = *status.best;
      // best solution value
      best.second.print();
      

      // should be in for loop for each iteration
      outputWriter+= "\"" + route_id + "\":" + 
         pTSP.returnOutput(best.first).dump() + ",";
   }
   // ================================================
   */
   // after loop, to be written a single time
   outputWriter.pop_back(); // gets rid of last ','
   std::ofstream jsonOutput("data/model_apply_outputs/proposed_sequences.json", std::ofstream::out);
   jsonOutput << "{" << outputWriter << "}";
   jsonOutput.close();
   //
   std::cout << "FINISHED" << std::endl;
   //
   return 0;
}
