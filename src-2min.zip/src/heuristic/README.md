# Folder that contains everything the C++ files from the main program

## OptAMZ.hpp
- Contains the context, evaluation, neighborhood searches, etc

## mainAMZ.cpp; mainAMZ-Historical.cpp
- Contains code that compiles the model-apply and model-build programs, respectively