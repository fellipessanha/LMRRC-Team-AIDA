#include <iostream>

#include <vastjson/VastJSON.hpp>
//
#include <nlohmann/json.hpp>

int main() { return 0; }
