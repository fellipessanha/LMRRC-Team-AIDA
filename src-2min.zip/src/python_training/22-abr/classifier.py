import datetime
import json
import datetime as dt
import sys
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
import pickle
from feature_engineering import FeatureEngineering


class BinaryClassifier:
    def __init__(self, feature_file, model_file):
        # read features file
        self.df = pd.read_json(feature_file)
        # model file name
        self.model_file = model_file

    # load features from file features.json and prepare the data for binary classification
    def load_features_binary_classifier(self):
        # create a map for the labels - Binary classification: High: 0, Medium/Low = 1
        label_dict = {"High": 1, "Medium": 0, "Low": 0}
        self.df['labels'] = self.df['route_score'].map(label_dict, na_action='ignore')
        # features
        X = self.df.loc[:, self.df.columns.difference(['routeID', 'route_score', 'labels'])].values
        # labels
        y = self.df.loc[:, 'labels']
        y = y.values.ravel()
        return X, y

    def load_prediction_features(self):
        # features
        X = self.df.loc[:, self.df.columns.difference(['routeID'])].values
        routeIDs = self.df.loc[:, 'routeID'].values
        return X, routeIDs

    # fit a logistic regression model using all historical data
    def fit_LogisticRegression_model(self, X, y):
        # feature scaling - standardize the features
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        # Train a linear regression model using the training sets
        lr = LogisticRegression()
        lr.fit(X, y)
        return lr

    # Fit selected model and save it in a pickle file
    # For now, considering logistic regression our best model
    def fit_model(self):
        X, y = self.load_features_binary_classifier()
        model = self.fit_LogisticRegression_model(X, y)
        # save the model to disk
        pickle.dump(model, open(self.model_file, 'wb'))

    def model_prediction(self):
        X, routeIDs = self.load_prediction_features()
        # Load model from file
        with open(self.model_file, 'rb') as file:
            model = pickle.load(file)
        y_predicted = model.predict_proba(X)
        for i in range(0, len(routeIDs)):
            print(str(routeIDs[i]) + '\t' + str(y_predicted[i]))

def do_train():
    # # model build: feature engineering
    fe = FeatureEngineering(phase='build', path_input='data/model_build_inputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_build_inputs/features.json', 'data/model_build_outputs/model.pkl')
    bc.fit_model()

def do_predict():
    # model build: feature engineering
    fe = FeatureEngineering(phase='apply', path_input='data/model_apply_inputs/', path_output='data/model_apply_outputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_apply_inputs/features.json', 'data/model_build_outputs/model.pkl')
    bc.model_prediction()


def main():
    """
    For now, I am considering the following structure for the data:
    Model Build
        data/model_build_inputs
        data/model_build_output
    Model Apply:
        data/model_apply_inputs
        data/model_apply_outputs
    """
    if len(sys.argv) != 2:
        return 'python3 classifier.py [build or apply]'
    if len(sys.argv) == 1 and (sys.argv[1] != 'build' or sys.argv[1] != 'apply'):
        return 'python3 classifier.py [build or apply]'

    if sys.argv[1] == 'build':
        # Training classifier
        do_train()
    else:  # apply
        do_predict()


if __name__ == '__main__':
    main()
