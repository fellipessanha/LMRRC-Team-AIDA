import sys
import pandas as pd
import pickle

from lightgbm import LGBMClassifier
from sklearn.ensemble import RandomForestClassifier
from feature_engineering import FeatureEngineering
from imblearn.over_sampling import SMOTE
from sklearn_porter import Porter


class BinaryClassifier:
    def __init__(self, feature_file, model_file):
        # features file
        self.feature_file = feature_file
        # model file name
        self.model_file = model_file

    # load features from file features.json and prepare the data for binary classification
    def load_features_binary_classifier(self):
        # read features file
        df = pd.read_json(self.feature_file)
        # create a map for the labels - Binary classification: High/Medium: 0, Low = 1
        label_dict = {"High": 0, "Medium": 0, "Low": 1}
        df['labels'] = df['route_score'].map(label_dict, na_action='ignore')
        return df

    def load_prediction_features(self):
        features_1 = ['Friday', 'Monday', 'Saturday', 'Sunday', 'Thursday', 'Tuesday', 'Wednesday', 'area',
                      'backtracking_count', 'max_packages_per_stop', 'max_time_btw_stops',
                      'median_time_btw_stops', 'min_packages_per_stop', 'min_time_btw_stops',
                      'ratio_delivery_time_packages_count', 'ratio_delivery_time_stops', 'ratio_early_violation',
                      'ratio_late_violation', 'ratio_package_count_violation_avg_time',
                      'ratio_package_count_violation_late_avg_time', 'ratio_package_volume_delivery_time',
                      'ratio_packages_count_delivery_time', 'ratio_route_size_delivery_time',
                      'ratio_route_size_travel_time', 'ratio_travel_time_packages_count',
                      'ratio_violation_delivery_time',
                      'ratio_violation_w_total_time', 'ratio_zones_delivery_time', 'ratio_zones_route_size',
                      'ratio_zones_travel_time', 'route_size', 'rush_hour_evening', 'rush_hour_morning',
                      'std_packages_per_stop', 'total_delivery_time', 'travel_time', 'violation_avg_time',
                      'violation_early_avg_time', 'violation_early_count', 'violation_early_total_time',
                      'violation_late_avg_time', 'violation_late_count', 'violation_total_time']
        # read features file
        df = pd.read_json(self.feature_file)
        # Get only a small set of features
        X = df.loc[:, features_1]
        routeIDs = df.loc[:, 'routeID'].values
        return X, routeIDs

    def fit_lightGBM_model(self, df):
        features_1 = ['Friday', 'Monday', 'Saturday', 'Sunday', 'Thursday', 'Tuesday', 'Wednesday', 'area',
                      'backtracking_count', 'max_packages_per_stop', 'max_time_btw_stops',
                      'median_time_btw_stops', 'min_packages_per_stop', 'min_time_btw_stops',
                      'ratio_delivery_time_packages_count', 'ratio_delivery_time_stops', 'ratio_early_violation',
                      'ratio_late_violation', 'ratio_package_count_violation_avg_time',
                      'ratio_package_count_violation_late_avg_time', 'ratio_package_volume_delivery_time',
                      'ratio_packages_count_delivery_time', 'ratio_route_size_delivery_time',
                      'ratio_route_size_travel_time', 'ratio_travel_time_packages_count',
                      'ratio_violation_delivery_time',
                      'ratio_violation_w_total_time', 'ratio_zones_delivery_time', 'ratio_zones_route_size',
                      'ratio_zones_travel_time', 'route_size', 'rush_hour_evening', 'rush_hour_morning',
                      'std_packages_per_stop', 'total_delivery_time', 'travel_time', 'violation_avg_time',
                      'violation_early_avg_time', 'violation_early_count', 'violation_early_total_time',
                      'violation_late_avg_time', 'violation_late_count', 'violation_total_time']

        # Get classes High and Low
        df_high = df.loc[df['route_score'] == 'High']
        df_low = df.loc[df['route_score'] == 'Low']
        df = df_high.append(df_low, ignore_index=True)

        # Get only a small set of features
        X = df.loc[:, features_1]
        y = df.loc[:, "labels"]

        # Run SMOTE to balance training data
        ros = SMOTE(random_state=42)
        X_resampled, y_resampled = ros.fit_resample(X, y)

        # Train model using lightGBM
        model = LGBMClassifier(random_state=0, boosting_type='goss', learning_rate=0.1, max_depth=20, n_estimators=100,
                               num_leaves=30)
        model.fit(X_resampled, y_resampled)
        return model

    # Fit selected model and save it in a pickle file
    # For now, considering logistic regression our best model
    def fit_model(self):
        df = self.load_features_binary_classifier()
        model = self.fit_lightGBM_model(df)
        # save the model to disk
        pickle.dump(model, open(self.model_file, 'wb'))

    def model_prediction(self):
        X, routeIDs = self.load_prediction_features()
        # Load model from file
        with open(self.model_file, 'rb') as file:
            model = pickle.load(file)

        y_predicted = model.predict_proba(X)
        predictions = {}
        for i in range(0, len(routeIDs)):
            predictions[routeIDs[i]] = y_predicted[i][1]
        print(predictions)
        return predictions


def do_train():
    # # model build: feature engineering
    fe = FeatureEngineering(phase='build', path_input='data/model_build_inputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_build_inputs/features.json', 'data/model_build_outputs/model.pkl')
    bc.fit_model()

def do_predict():
    # model build: feature engineering
    fe = FeatureEngineering(phase='apply', path_input='data/model_apply_inputs/', path_output='data/model_apply_outputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_apply_inputs/features.json', 'data/model_build_outputs/model.pkl')
    bc.model_prediction()


def main():
    """
    For now, I am considering the following structure for the data:
    Model Build
        data/model_build_inputs
        data/model_build_output
    Model Apply:
        data/model_apply_inputs
        data/model_apply_outputs
    """
    if len(sys.argv) != 2:
        return 'python3 classifier.py [build or apply]'
    if len(sys.argv) == 1 and (sys.argv[1] != 'build' or sys.argv[1] != 'apply'):
        return 'python3 classifier.py [build or apply]'

    if sys.argv[1] == 'build':
        # Training classifier
        do_train()
    else:  # apply
        do_predict()


if __name__ == '__main__':
    main()
