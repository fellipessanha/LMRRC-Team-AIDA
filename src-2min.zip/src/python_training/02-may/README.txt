@dvianna

Compartilhando com voces o que temos pronto em Python: (1) feature_engineering.py; (2) classifier_v2.py
(1) feature_engineering.py: le os arquivos do data/model_build_inputs e gera um arquivo de features.
(2) classifier_v2.py. Esse arquivo tem duas opcoes: build e apply
python3 classifier_v2.py build ==> chama a funcao do_train(). Essa funcao ira chamar o feature_engineering.py para gerar as features para o dado historico. Em seguida, um modelo e' treinado usando SMOTE + LightGBM. O modelo gerado e' salvo em um arquivo pickle.
python3 classifier_v2.py apply ==> chama a funcao do_predict(). Essa funcao ira chamar o feature_engineering.py para gerar as features para as novas rotas. Em seguida, o modelo treinado no passo anterior, e' carregado e as predicoes sao realizadas. Por enquanto, esse arquivo retorna o RouteID e a probabilidade da rota ser Low. (Exemplo: {RouteID_15baae2d-bf07-4967-956a-173d4036613f :  0.99844452}). 
Lembrando, que para essa primeira solucao temos apenas duas classes: 0: High/Medium e 1: Low

--------
Observacoes:
(1) Para a fase build, treinamento do classificador, o classifier_v2.py esta treinando o modelo com todas as rotas historicas. Se a gente optar em separar esse dado historico para testes, por exemplo, usando algumas rotas High como gabarito, 'e importante tirar essas rotas do treinamento. Essa remocao pode ser feita nos arquivos do data/model_build_inputs, ou dentro do proprio codigo.
(2) No momento, para a fase apply, o classifier le as rotas do arquivo proposed_sequences.

