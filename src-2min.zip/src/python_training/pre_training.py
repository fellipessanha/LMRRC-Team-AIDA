import datetime
import json
import datetime as dt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectKBest, mutual_info_classif
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.calibration import calibration_curve
from feature_engineering import FeatureEngineering
from sklearn.metrics import precision_score, recall_score, f1_score
from matplotlib import pyplot
from bioinfokit import visuz


class BinaryClassifier:
    def __init__(self, feature_file):
        # read features file
        self.df = pd.read_json(feature_file)

    def tuning_hyperparameters(self):
        X, y = self.load_features_binary_classifier()
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=0)
        pipe = Pipeline([('scaler', StandardScaler()),
                         ('classifier', LogisticRegression())])

        # search_space = [{'classifier': [LogisticRegression()],
        #                  'classifier__solver': ['lbfgs', 'liblinear'],
        #                  'classifier__C': [0.0001, 0.001, 0.01, 0.1, 1.0, 10.0, 100.0]},
        #                 {'classifier': [RandomForestClassifier()],
        #                  'classifier__n_estimators': [10, 100, 200],
        #                  'classifier__max_depth': [2, 5, 10, 15, 20, None],
        #                  'classifier__min_samples_split': [2, 5],
        #                  'classifier__min_samples_leaf': [1, 5]},
        #                 {'classifier': [KNeighborsClassifier()],
        #                  'classifier__n_neighbors': [2, 5, 10, 15, 20],
        #                  'classifier__weights': ['uniform', 'distance']},
        #                 {'classifier': [SVC()],
        #                  'classifier__kernel': ['linear'],
        #                  'classifier__C': [0.001, 0.01, 0.1, 1.0, 10.0, 100],
        #                  'classifier__gamma': [0.001, 0.01, 0.1, 1.0, 10.0, 100]},
        #                 {'classifier': [DecisionTreeClassifier(random_state=0)],
        #                  'classifier__max_depth': [2, 5, 10, 15, 20, None],
        #                  'classifier__min_samples_split': [2, 5],
        #                  'classifier__min_samples_leaf': [1, 5]},
        #                 {'classifier': [GaussianNB()]}]

        search_space = [{'classifier': [LogisticRegression()],
                         'classifier__penalty': ['l1', 'l2'],
                         'classifier__solver': ['liblinear'],
                         'classifier__C': [0.000001, 0.00001, 0.0001, 0.001, 0.01, 0.1, 1.0, 10.0, 100.0]},
                        {'classifier': [SVC()],
                         'classifier__kernel': ['linear'],
                         'classifier__C': [0.000001, 0.00001, 0.0001, 0.001, 0.01, 0.1, 1.0, 10.0, 100]}
                        ]

        clf = GridSearchCV(pipe, search_space, cv=10, verbose=0, scoring='f1_macro')
        clf = clf.fit(X_train, y_train)

        print("Best parameters set found on development set:")
        print()
        print(clf.best_params_)
        print()
        print("Grid scores on development set:")
        print()
        means = clf.cv_results_['mean_test_score']
        stds = clf.cv_results_['std_test_score']
        for mean, std, params in zip(means, stds, clf.cv_results_['params']):
            print("%0.3f (+/-%0.03f) for %r"
                  % (mean, std * 2, params))
        print()

        print("Detailed classification report:")
        print()
        print("The model is trained on the full development set.")
        print("The scores are computed on the full evaluation set.")
        print()
        y_true, y_pred = y_test, clf.predict(X_test)
        print(classification_report(y_true, y_pred))
        print()

    """
    Well calibrated classifiers are probabilistic classifiers for which the output of the predict_proba method can be 
    directly interpreted as a confidence level. For instance a well calibrated (binary) classifier should classify the 
    samples such that among the samples to which it gave a predict_proba value close to 0.8, approx. 80% actually 
    belong to the positive class.
    """
    def plot_calibration(self):
        X, y = self.load_features_binary_classifier()
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=0)

        # feature scaling - standardize the features
        scaler = StandardScaler()
        scaler.fit(X_train)
        # scale training data
        X_train = scaler.transform(X_train)

        # feature scaling - standardize the features
        X_test = scaler.transform(X_test)

        # Create classifiers
        lr = LogisticRegression(C=0.1, solver='liblinear')
        svc = SVC(C=1.0, kernel='linear')

        # #############################################################################
        # Plot calibration plots

        plt.figure(figsize=(10, 10))
        ax1 = plt.subplot2grid((3, 1), (0, 0), rowspan=2)
        ax2 = plt.subplot2grid((3, 1), (2, 0))

        ax1.plot([0, 1], [0, 1], "k:", label="Perfectly calibrated")

        for clf, name in [(lr, 'Logistic'),
                          (svc, 'Support_Vector_Classification')]:
            clf.fit(X_train, y_train)

            y_pred = clf.predict(X_test)
            if hasattr(clf, "predict_proba"):
                prob_pos = clf.predict_proba(X_test)[:, 1]
            else:  # use decision function
                prob_pos = clf.decision_function(X_test)
                prob_pos = (prob_pos - prob_pos.min()) / (prob_pos.max() - prob_pos.min())
            fraction_of_positives, mean_predicted_value = calibration_curve(y_test, prob_pos, n_bins=10)

            ax1.plot(mean_predicted_value, fraction_of_positives, "s-", label="%s" % (name,))

            ax2.hist(prob_pos, range=(0, 1), bins=10, label=name, histtype="step", lw=2)
            print("\tPrecision: %1.3f" % precision_score(y_test, y_pred))
            print("\tRecall: %1.3f" % recall_score(y_test, y_pred))
            print("\tF1: %1.3f\n" % f1_score(y_test, y_pred))

        ax1.set_ylabel("Fraction of positives")
        ax1.set_ylim([-0.05, 1.05])
        ax1.legend(loc="lower right")
        ax1.set_title('Calibration plots  (reliability curve)')

        ax2.set_xlabel("Mean predicted value")
        ax2.set_ylabel("Count")
        ax2.legend(loc="upper center", ncol=2)

        plt.tight_layout()
        plt.savefig('calibration.png')

    def plot_correlation(self):
        X = self.df.loc[:, self.df.columns.difference(['routeID', 'route_score', 'labels'])]
        visuz.stat.corr_mat(df=X, cmap='RdBu')

    def feature_importance(self):
        X, y = self.load_features_binary_classifier()
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=0)

        # feature scaling - standardize the features
        scaler = StandardScaler()
        scaler.fit(X_train)
        # scale training data
        X_train = scaler.transform(X_train)

        # Create classifiers
        lr = LogisticRegression(C=0.0001, penalty='l2', solver='liblinear')

        for clf, name in [(lr, 'Logistic')]:
            clf.fit(X_train, y_train)
            self.plot_feature_importance(clf, name)
            self.plot_feature_importance_2(clf, name)

    # Plot feature importance
    def plot_feature_importance(self, clf, name):
        X = self.df.loc[:, self.df.columns.difference(['routeID', 'route_score', 'labels'])]
        feature_importance = abs(clf.coef_[0])
        feature_importance = 100.0 * (feature_importance / feature_importance.max())
        sorted_idx = np.argsort(feature_importance)
        pos = np.arange(sorted_idx.shape[0]) + .5
        featfig = plt.figure(figsize=(25, 20))
        featax = featfig.add_subplot(1, 1, 1)
        featax.barh(pos, feature_importance[sorted_idx], align='center')
        featax.set_yticks(pos)
        featax.set_yticklabels(np.array(X.columns)[sorted_idx], fontsize=8)
        featax.set_xlabel('Relative Feature Importance')
        file_name = 'featureImportance_' + name
        plt.savefig(file_name)

    def plot_feature_importance_2(self, clf, name):
        X = self.df.loc[:, self.df.columns.difference(['routeID', 'route_score', 'labels'])]
        # get importance
        importance = clf.coef_[0]
        labels = []
        print('Feature Importance: ')
        # summarize feature importance
        for i, v in enumerate(importance):
            print('Feature: %0d (%s), Score: %.5f' % (i, X.columns[i], v))
            labels.append(X.columns[i])

        coefs = pd.DataFrame(
            importance,
            columns=['Coefficients'], index=labels
        )
        coefs.plot(kind='bar', figsize=(25, 25))
        plt.title('Model Coefficients as Feature Importance Scores')
        file_name = 'coefficients_' + name
        plt.savefig(file_name)

    def checking_model(self):
        X, y = self.load_features_binary_classifier()
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=0)
        # feature scaling - standardize the features
        scaler = StandardScaler()
        scaler.fit(X_train)
        # scale training data
        X_train = scaler.transform(X_train)
        # Run logistic regression
        lr = LogisticRegression()
        lr.fit(X_train, y_train)
        # plot feature importance
        self.plot_feature_importance(lr)

        # feature scaling - standardize the features
        X_test = scaler.transform(X_test)
        # predictions
        y_train_pred = lr.predict(X_train)
        y_test_pred = lr.predict(X_test)
        # Classification Report
        print(classification_report(y_test, y_test_pred))

    # load features from file features.json and prepare the data for binary classification
    def load_features_binary_classifier(self):
        # create a map for the labels - Binary classification: High: 0, Medium/Low = 1
        label_dict = {"High": 1, "Medium": 0, "Low": 0}
        self.df['labels'] = self.df['route_score'].map(label_dict, na_action='ignore')

        # features
        X = self.df.loc[:, self.df.columns.difference(['routeID', 'route_score', 'labels'])].values
        # labels
        y = self.df.loc[:, 'labels']
        y = y.values.ravel()
        return X, y

def main():
    # model build: feature engineering
    fe = FeatureEngineering(phase='build', path_input='data/model_build_inputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_build_inputs/features.json')
    bc.tuning_hyperparameters()
    bc.plot_calibration()
    bc.feature_importance()


if __name__ == '__main__':
    main()
