import sys
import pandas as pd
import pickle

from lightgbm import LGBMClassifier
from feature_engineering import FeatureEngineering
from imblearn.over_sampling import SMOTE


class BinaryClassifier:
    def __init__(self, feature_file, model_file):
        # features file
        self.feature_file = feature_file
        # model file name
        self.model_file = model_file

    # load features from file features.json and prepare the data for binary classification
    def load_features_binary_classifier(self):
        # read features file
        df = pd.read_json(self.feature_file)
        # create a map for the labels - Binary classification: High/Medium: 0, Low = 1
        label_dict = {"High": 0, "Medium": 0, "Low": 1}
        df['labels'] = df['route_score'].map(label_dict, na_action='ignore')
        return df

    def load_prediction_features(self):
        features_1 = ['Friday', 'Monday', 'Saturday', 'Sunday', 'Thursday', 'Tuesday', 'Wednesday', 'area',
                      'backtracking_count', 'max_packages_per_stop', 'max_time_btw_stops',
                      'median_time_btw_stops', 'min_packages_per_stop', 'min_time_btw_stops',
                      'ratio_delivery_time_packages_count', 'ratio_delivery_time_stops', 'ratio_early_violation',
                      'ratio_late_violation', 'ratio_package_count_violation_avg_time',
                      'ratio_package_count_violation_late_avg_time', 'ratio_package_volume_delivery_time',
                      'ratio_packages_count_delivery_time', 'ratio_route_size_delivery_time',
                      'ratio_route_size_travel_time', 'ratio_travel_time_packages_count',
                      'ratio_violation_delivery_time',
                      'ratio_violation_w_total_time', 'ratio_zones_delivery_time', 'ratio_zones_route_size',
                      'ratio_zones_travel_time', 'route_size', 'rush_hour_evening', 'rush_hour_morning',
                      'std_packages_per_stop', 'total_delivery_time', 'travel_time', 'violation_avg_time',
                      'violation_early_avg_time', 'violation_early_count', 'violation_early_total_time',
                      'violation_late_avg_time', 'violation_late_count', 'violation_total_time']
        # read features file
        df = pd.read_json(self.feature_file)
        # Get only a small set of features
        X = df.loc[:, features_1]
        routeIDs = df.loc[:, 'routeID'].values
        return X, routeIDs

    def fit_lightGBM_model(self, df):
        features_1 = ['Friday', 'Monday', 'Saturday', 'Sunday', 'Thursday', 'Tuesday', 'Wednesday', 'area',
                      'backtracking_count', 'max_packages_per_stop', 'max_time_btw_stops',
                      'median_time_btw_stops', 'min_packages_per_stop', 'min_time_btw_stops',
                      'ratio_delivery_time_packages_count', 'ratio_delivery_time_stops', 'ratio_early_violation',
                      'ratio_late_violation', 'ratio_package_count_violation_avg_time',
                      'ratio_package_count_violation_late_avg_time', 'ratio_package_volume_delivery_time',
                      'ratio_packages_count_delivery_time', 'ratio_route_size_delivery_time',
                      'ratio_route_size_travel_time', 'ratio_travel_time_packages_count',
                      'ratio_violation_delivery_time',
                      'ratio_violation_w_total_time', 'ratio_zones_delivery_time', 'ratio_zones_route_size',
                      'ratio_zones_travel_time', 'route_size', 'rush_hour_evening', 'rush_hour_morning',
                      'std_packages_per_stop', 'total_delivery_time', 'travel_time', 'violation_avg_time',
                      'violation_early_avg_time', 'violation_early_count', 'violation_early_total_time',
                      'violation_late_avg_time', 'violation_late_count', 'violation_total_time']

        # Get classes High and Low
        df_high = df.loc[df['route_score'] == 'High']
        df_low = df.loc[df['route_score'] == 'Low']
        df = df_high.append(df_low, ignore_index=True)

        routes_to_remove = ['RouteID_880a3c32-6071-41ad-b387-8620d36285de', 'RouteID_e02d4edc-b5dd-471d-9508-66f4b71852af',
                            'RouteID_679369bd-44cd-440a-a962-e7400d52e21b', 'RouteID_9ea87ee2-867b-4cc0-ab72-f76d8389182a',
                            'RouteID_e97b9afc-7b6d-4139-8d09-be696884e30c', 'RouteID_001948e9-4675-486d-9ec5-912fd8e0770f',
                            'RouteID_b1e0fa64-9d03-431f-8a50-26003fe670cd', 'RouteID_c54aa8d4-5b3c-4326-ad3e-09b11f58975b',
                            'RouteID_19e1c1d3-5abc-4ed6-a6f0-62e5fa2b7655', 'RouteID_77ea19bb-3f67-4474-ae8a-dc24f2739bab',
                            'RouteID_aac5b390-fa8e-46aa-bf5f-998ae5c07c5f', 'RouteID_2c635c41-a967-4fad-8a54-ba6bd2d62c30',
                            'RouteID_54756ba3-40b8-4c03-8465-7fd4fac2a7e1', 'RouteID_3371790e-acf0-44d7-9291-787cb67b499f',
                            'RouteID_39d0e251-8fd5-42ed-b703-fb2cb2854c86', 'RouteID_8e86da60-9fe5-4021-8038-9f45cd81508c',
                            'RouteID_ac7d83a3-7c3b-4a92-924a-32781027b946', 'RouteID_fe9d5d17-45c9-4e61-9e15-a8fb74f06be3',
                            'RouteID_58a6906b-aa93-4225-941e-8512c1e15aec', 'RouteID_9ad2a71c-906a-4504-9bc2-4b143334e95a',
                            'RouteID_fe2c4004-f3bf-4a2e-b1b8-43f870e4f185', 'RouteID_cb8b2c27-9978-4b88-8106-13b865d5b862',
                            'RouteID_6d8e8218-9287-473e-a656-7bea9c22a123', 'RouteID_6c627360-4900-4bc9-9105-ee73d173b848',
                            'RouteID_95cf26e3-2dde-4790-aa5d-5fe5e5a506ac', 'RouteID_fbf71391-2e95-45f9-9f8e-8620cff27a3d',
                            'RouteID_ea421f5c-0f26-48ba-b6e1-5d31a9c7efa0', 'RouteID_6a59472a-e70b-4f8d-aed6-a93840a27cbe',
                            'RouteID_6f59b71d-818d-4a39-a01e-6e86276ff79b', 'RouteID_a528db29-ebb3-4264-99a3-e26fdbb61c1f',
                            'RouteID_b78695ba-8acb-4cd3-8f2c-022c372d85e8', 'RouteID_d10299e0-eb32-4185-8f4f-462db930f6d1',
                            'RouteID_b7c4299c-be13-4cb3-ae99-6822f6fa8ca4', 'RouteID_5b253a36-8ef8-4e6a-bd1c-71180596e46f',
                            'RouteID_98a83cb8-2498-421a-a5be-b4ccca04ac71', 'RouteID_ae6eac32-403a-4c1a-8ccb-b8bdcaf25bad',
                            'RouteID_f53d09f3-721d-456d-aa62-5b9469ea63ba', 'RouteID_e7d90bca-f04a-4502-bfb0-5914071b4712',
                            'RouteID_57af31ed-73bb-4183-8074-11ec6d1df083', 'RouteID_cac6e99d-5a58-4800-bd63-4892de140a54',
                            'RouteID_8ddc4ae5-da2b-4572-8758-57b46a3adcfb', 'RouteID_e7bceef0-724d-4ca6-b4be-c36361b132f2',
                            'RouteID_0baf9c14-6f12-4a24-86d4-66db6a30dae5', 'RouteID_56e66ffc-e668-4b42-ae4c-843c74406af0',
                            'RouteID_a09b99fd-d868-41c6-b32e-6ea828fa4f79', 'RouteID_8f40d72c-c84c-4c35-8b67-e013f1113525',
                            'RouteID_9a70b345-e627-4849-a86e-8f735c9fcbde', 'RouteID_40de7cab-aed7-488d-ba53-322900222c7b',
                            'RouteID_e44ac5b6-e650-4ad7-9c66-e79576d34af7', 'RouteID_4a17ea28-88d4-4437-9fd8-69b7d5c9fc9b',
                            'RouteID_c3069c8b-13c7-4e69-a25c-d15dd70e3b76', 'RouteID_3c07276d-c213-4278-94fc-33046f48bcbf',
                            'RouteID_46ead2f2-e1e3-4ab3-838f-835a944d6a59', 'RouteID_65afce43-9ef2-47e2-8875-5d94d01d2a10',
                            'RouteID_da90b76c-6986-4197-81fa-0e33aa51dd44', 'RouteID_668be283-2e93-488e-9184-94c144c4a6fb',
                            'RouteID_33400281-e8fc-439e-b550-045ecb5d5d60', 'RouteID_6b7f00d4-bb6d-480b-b90b-42604dab4563',
                            'RouteID_8ccc45dd-e94f-43a8-81c5-8bd466e0c8a0', 'RouteID_00143bdd-0a6b-49ec-bb35-36593d303e77',
                            'RouteID_b7be564a-3338-4bba-aa3b-149f3ffbb64d', 'RouteID_6fd45936-8921-49bd-b9c3-e690bbd1b11d',
                            'RouteID_c01480b7-ba76-462e-8c4a-0046edad9170', 'RouteID_606217f3-b754-4b7b-94be-579fe5f06475',
                            'RouteID_93cbc871-5f6c-4212-9ef6-65777c220c98', 'RouteID_dac87cd3-6aa2-4c29-9f43-504111d2fd4a',
                            'RouteID_d65fd4f5-0ac1-4d83-b81f-eace712bb6d0', 'RouteID_263d06d8-5d33-4805-b015-24035935f09c',
                            'RouteID_80987246-f4ca-4263-bebf-eb3e75fcbce1', 'RouteID_9261c89b-0095-4e15-b68c-8b9a4cc087f6',
                            'RouteID_ed6c5f23-9b03-4feb-b2a6-b45b0350aa9e', 'RouteID_b0ce27bb-ecea-4d12-a83c-bbcd02c70bb4',
                            'RouteID_a7a5c051-efea-431f-998a-f4bb8454e7e3', 'RouteID_de6b24e2-00d7-49cf-9c6d-76de884d0eb2',
                            'RouteID_bbe190c2-ff7a-436d-9230-a002271ee3e4', 'RouteID_d208f5b0-e60e-4a7a-af1c-6cce62856747',
                            'RouteID_d9e8d1a2-f9f7-412f-a7de-db5c98c6829a', 'RouteID_3622549d-1e92-4bca-904d-f95b229dc1ae',
                            'RouteID_386144ab-ba26-413b-8644-8c88db55b042', 'RouteID_a2c4695d-dcad-4975-84e6-c6b249c644ed',
                            'RouteID_eb092c67-431e-4a2d-8739-1fa47e39dde4', 'RouteID_a9146121-cad0-48ad-94c6-282e3866e06d',
                            'RouteID_4e6a1048-3174-4c3e-8e7f-e9982a5d1f72', 'RouteID_e8fadfda-0160-40d7-8a89-7bedbe0502e5',
                            'RouteID_3484a110-b82b-4c64-b13a-14cae99d5a4f', 'RouteID_4911a788-48d0-4229-ac92-a70d3a5fa2cf',
                            'RouteID_ac9c6b4e-3fdf-43b3-b3af-8754089360aa', 'RouteID_03b80f56-768d-4ecd-95ac-1a32c4e04127',
                            'RouteID_01ac92ea-734c-4c80-8049-77b813c6a02b', 'RouteID_2daf76cc-2b1a-4c42-86a0-e0b9ff042959',
                            'RouteID_57e75fc6-a866-486c-b693-2e48ab4b6436', 'RouteID_e5804ac5-fbb9-46e8-ba58-3b77d08a2575',
                            'RouteID_25587c48-577e-4e4a-9a93-70f5193938ca', 'RouteID_00747543-3f2f-47ae-a2f2-91b30ce207ab',
                            'RouteID_30f7acd9-5253-4904-9ebf-baebfb119449', 'RouteID_bfe4ee11-d28b-4289-a2aa-ea3709504c1e',
                            'RouteID_ee4cdef8-941b-4a6a-99da-f7dd049438fa', 'RouteID_6818b10c-8ead-42ce-8ee6-3e1ab7e307f6',
                            'RouteID_4fcff59e-6155-470a-be78-09cda8c1480b', 'RouteID_7f11ac39-2869-4017-a4dc-6757e108f1a3']

        df = df.loc[~df['routeID'].isin(routes_to_remove)]

        # Get only a small set of features
        X = df.loc[:, features_1]
        y = df.loc[:, "labels"]

        # Run SMOTE to balance training data
        ros = SMOTE(random_state=42)
        X_resampled, y_resampled = ros.fit_resample(X, y)

        # Train model using lightGBM
        model = LGBMClassifier(random_state=0, boosting_type='goss', learning_rate=0.1, max_depth=20, n_estimators=100,
                               num_leaves=30)
        model.fit(X_resampled, y_resampled)
        return model

    # Fit selected model and save it in a pickle file
    # For now, considering logistic regression our best model
    def fit_model(self):
        df = self.load_features_binary_classifier()
        model = self.fit_lightGBM_model(df)
        # save the model to disk
        pickle.dump(model, open(self.model_file, 'wb'))

    def model_prediction(self):
        X, routeIDs = self.load_prediction_features()
        # Load model from file
        with open(self.model_file, 'rb') as file:
            model = pickle.load(file)

        y_predicted = model.predict_proba(X)
        predictions = {}
        for i in range(0, len(routeIDs)):
            predictions[routeIDs[i]] = y_predicted[i][1]
        print(predictions)
        return predictions


def do_train():
    # # model build: feature engineering
    fe = FeatureEngineering(phase='build', path_input='data/model_build_inputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_build_inputs/features.json', 'data/model_build_outputs/model.pkl')
    bc.fit_model()

def do_predict():
    # model build: feature engineering
    fe = FeatureEngineering(phase='apply', path_input='data/model_apply_inputs/', path_output='data/model_apply_outputs/')
    fe.create_features()
    # model build: binary classifier
    bc = BinaryClassifier('data/model_apply_inputs/features.json', 'data/model_build_outputs/model.pkl')
    bc.model_prediction()


def main():
    """
    For now, I am considering the following structure for the data:
    Model Build
        data/model_build_inputs
        data/model_build_output
    Model Apply:
        data/model_apply_inputs
        data/model_apply_outputs
    """
    if len(sys.argv) != 2:
        return 'python3 classifier.py [build or apply]'
    if len(sys.argv) == 1 and (sys.argv[1] != 'build' or sys.argv[1] != 'apply'):
        return 'python3 classifier.py [build or apply]'

    if sys.argv[1] == 'build':
        # Training classifier
        do_train()
    else:  # apply
        do_predict()


if __name__ == '__main__':
    main()
