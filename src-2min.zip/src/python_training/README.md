# Where we store the AI part of the training.

- feature_engineering.py has the function create_features, which creates the features we need for the other programs

- classifier.py is what the heuristic will use. It creates predictions for a certain route

- pre_training.py is used to generate hyperparameters and plots