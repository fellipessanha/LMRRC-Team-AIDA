import datetime
import json
import datetime as dt
import numpy as np
import sys


class FeatureEngineering:
    def __init__(self, phase='build', path_input='.', path_output='.'):
        self.phase = phase
        if phase == 'build':
            self.route_data_file = path_input + 'route_data.json'
            self.package_data_file = path_input + 'package_data.json'
            self.travel_times_file = path_input + 'travel_times.json'
            self.actual_sequences_file = path_input + 'actual_sequences.json'
            self.features_file = path_input + 'features.json'
        else: # phase == apply
            self.route_data_file = path_input + 'new_route_data.json'
            self.package_data_file = path_input + 'new_package_data.json'
            self.travel_times_file = path_input + 'new_travel_times.json'
            self.actual_sequences_file = path_output + 'proposed_sequences.json'
            self.features_file = path_input + 'features.json'

    """
        Loading data: route_data, package_data, travel_times, actual_sequences
    """
    def load_data(self):
        # load route date
        with open(self.route_data_file, 'r') as fp:
            route_data = json.loads(fp.read())
        fp.close()
        # load package date
        with open(self.package_data_file, 'r') as fp:
            package_data = json.loads(fp.read())
        fp.close()
        # load travel times date
        with open(self.travel_times_file, 'r') as fp:
            travel_times_data = json.loads(fp.read())
        fp.close()
        # load actual sequences date
        with open(self.actual_sequences_file, 'r') as fp:
            actual_sequences_data = json.loads(fp.read())
        fp.close()
        return route_data, package_data, travel_times_data, actual_sequences_data

    def light_parse(self, bigdata):
        ret_data = {}
        routeStart = bigdata.find("\"RouteID")
        while routeStart > 0:
            nameEnd = bigdata.find("\"", routeStart+1)
            routeName = bigdata[routeStart+1:nameEnd]
            routeEnd = bigdata.find("\"RouteID", routeStart+1)
            if routeEnd > 0:
                # Compensate for "," character separating routes
                routeEnd = bigdata.rfind(",", routeStart+1, routeEnd)
                # Must have these extra {} else json.loads() complains
                currRoute = "{"+bigdata[routeStart:routeEnd]+"}"
            else:
                currRoute = "{"+ bigdata[routeStart:]
            ret_data[routeName] = currRoute
            routeStart = bigdata.find("\"RouteID", routeStart+1)

        return ret_data

    def light_load_data(self):
        # load route date
        with open(self.route_data_file, 'r') as fp:
            string_data = fp.read()
        fp.close()
        route_data = self.light_parse(string_data)

        # load package date
        with open(self.package_data_file, 'r') as fp:
            string_data = fp.read()
        fp.close()
        package_data = self.light_parse(string_data)

        # load travel times date
        with open(self.travel_times_file, 'r') as fp:
            string_data = fp.read()
        fp.close()
        travel_times_data = self.light_parse(string_data)

        # load actual sequences date
        with open(self.actual_sequences_file, 'r') as fp:
            string_data = fp.read()
        fp.close()
        actual_sequences_data = self.light_parse(string_data)

        return route_data, package_data, travel_times_data, actual_sequences_data

    """
    TODO: Check this method for correctness
    Checks whether route goes through any portion of the rush hour
    """
    def time_in_between(self, rush_hour, start_route, end_route):
        if (start_route < rush_hour[1] and end_route > rush_hour[0]) or \
                (start_route > rush_hour[1] and end_route > rush_hour[0]) or \
                (start_route < rush_hour[1] and (end_route < start_route)) or \
                (rush_hour[0] < start_route < rush_hour[1]) or \
                (rush_hour[0] < end_route < rush_hour[1]):
            return 1
        else:
            return 0

    """
        Train/test features
    """
    def create_features(self, json_light = False):
        # load data
        if json_light:
            route_data, package_data, travel_times_data, actual_sequences_data = self.light_load_data()
        else:
            route_data, package_data, travel_times_data, actual_sequences_data = self.load_data()

        # feature vector and labels
        all_features = []

        """
        Features:
        routeID: route id
        route_size: route size (number of stops per route)
        total_delivery_time: route total time (distance + time for package delivery)
        travel_time: time to travel between stops (distance)
        violation_count: window violation count
        violation_avg_time: window violation average time (seconds)
        violation_total_time: window violation total time (seconds)
        ratio_violation: ratio between window violation time and window total time        
        violation_early_total_time: window violation total time - arrived early (time in seconds)
        violation_late_total_time: window violation total time - arrived late (time in seconds)
        violation_early_avg_time: window violation avg time - arrived early (time in seconds)
        violation_late_avg_time: window violation avg time - arrived late (time in seconds)
        violation_early_count:  window violation count - arrived early
        violation_late_count: window violation time - arrived late
        ratio_early_violation: ratio between window violation time and window total time - arrived early
        ratio_late_violation: ratio between window violation time and window total time - arrived late       
        zones_count: number of unique zones per route
        backtracking_count: backtracking count (number of times a driver leaves and then goes back to a zone) 
        ratio_backtracking_route_size: ratio between backtracking count and route size
        ratio_backtracking_route_zones: ratio between backtracking count and number of unique zones in a route
        
        NEW
        
        ratio_delivery_time_stops: ratio between delivery time and number of stops
        ratio_zones_delivery_time: ratio between number of unique zones and delivery time 
        ratio_route_size_delivery_time: ratio between route size (number of stops) and delivery time
        ratio_packages_count_delivery_time: ratio between number of packages and delivery time
        ratio_violation_delivery_time: ratio between window violation count and delivery time (route size)
        ratio_delivery_time_stops: ratio between delivery time and number of stops (route size)
        ratio_delivery_time_packages_count: ratio between delivery time and number of packages
        
        ratio_travel_time_stops: ratio between travel time and number of stops        
        ratio_zones_route_size: ratio between number of unique zones and route size (number of stops per route)
        ratio_zones_travel_time: ratio between number of unique zones and travel time 
        ratio_route_size_travel_time: ratio between route size (number of stops) and travel time
        ratio_packages_count_travel_time: ratio between number of packages and travel time
        ratio_packages_count_route_size: ratio between number of packages and route size (number of stops per route)
        ratio_violation_travel_time: ratio between window violation count and travel time (route size)
        ratio_travel_time_stops: ratio between travel time and number of stops (route size)
        ratio_travel_time_packages_count: ratio between travel time and number of packages
        ratio_package_count_violation_avg_time: ratio between average number of packages (not delivered on time) and 
        window violation average time
        ratio_package_count_violation_total_time: ratio between packages count (not delivered on time) and window 
        violation total time
        ratio_package_count_violation_late_avg_time: ratio between avg packages count (delivered late) and window 
        violation (late) average time
        ratio_package_count_violation_late_total_time: ration between total packages count (delivered late) and window 
        violation (late) total time
        ratio_package_volume_delivery_time: ratio between packages volume and delivery time
        ratio_package_volume_violation_time: ratio between packages volume (not delivered on time) and window violation 
        total time
        ratio_package_volume_violation_late_total_time: ratio between packages (not delivered on time) volume and window 
        violation (late) total time      
        rush_hour_morning (7am-9am): route went through morning rush hour
        rush_hour_evening (5pm-7pm): route went through evening rush hour  
        
        MISSING:
        distance: distance (km)
        ratio_distance_travel_time: ratio between distance and total travel time
        ratio_distance_route_size: ratio between distance and number of stops (average distance)
        ratio between avg distance between two stops and time window violation
        
        MAYBE:        
        One feature per zone - help to identify difficult routes
        
        """
        # For each route, compute new features
        for routeID in route_data.keys():

            if json_light:
                route = json.loads(route_data[routeID])
                package_data = json.loads(package_data[routeID])
                travel_times_data = json.loads(travel_times_data[routeID])
                actual_sequences_data = json.loads(actual_sequences_data[routeID])

            # create feature dictionary for each route
            features = {'routeID': routeID}
            # get route data
            route = route_data[routeID]
            route_date = route['date_YYYY_MM_DD']
            route_departure_time = route['departure_time_utc']
            # route_size: route size (number of stops per route)
            route_size = len(route["stops"].keys())
            features['route_size'] = route_size

            # combine attributes date_YYYY_MM_DD with departure_time_utc
            date = dt.datetime.strptime(route['date_YYYY_MM_DD'], '%Y-%m-%d')
            time = dt.datetime.strptime(route['departure_time_utc'], '%H:%M:%S').time()
            start_time = dt.datetime.combine(date, time)

            # get actual sequence
            if self.phase == 'build':
                sequence = actual_sequences_data[routeID]['actual']
            else:  # self.phase = 'apply'
                sequence = actual_sequences_data[routeID]['proposed']
            sequence = sorted(sequence, key=sequence.get)
            # travel and delivery time variables
            travel_time = 0
            delivery_time = 0
            total_delivery_time = 0
            # time window for package delivery
            tw_violated = 0
            tw_violated_early = 0
            tw_violated_late = 0
            # time window difference when violated (total per route)
            difference = 0
            difference_early = 0
            difference_late = 0
            # time window for all stops (total em seconds)
            tw_total = 0
            # zones sequence
            zones = []
            backtracking = 0
            unique_zones = 0
            # packages count
            package_count = 0
            package_count_violation = 0
            package_count_late_violation = 0
            # packages volume
            package_volume = 0
            package_volume_late_violation = 0
            for index in range(0, len(sequence)-1):
                # variables used to check time window per stop
                tw_start = 0
                tw_end = 0
                has_time_window = False
                # travel time
                travel_time += travel_times_data[routeID][sequence[index]][sequence[index+1]]
                # total number of packages per stop
                packages_per_stop = 0
                # total volume of packages per stop
                package_volume_stop = 0
                # stop sequence[0] is the delivery station. There are no packages to be delivery at this stop.
                # compute time to delivery all packages from the same stop
                for pkg in package_data[routeID][sequence[index+1]]:
                    # counting total number of packages
                    package_count += 1
                    # counting number of packages in this stop
                    packages_per_stop += 1
                    # At this point, I am considering that planned_service_time_seconds is the same for all packages.
                    if package_data[routeID][sequence[index+1]][pkg]['planned_service_time_seconds']:
                        service_time = package_data[routeID][sequence[index+1]][pkg]['planned_service_time_seconds']
                    if not (isinstance(package_data[routeID][sequence[index+1]][pkg]['time_window']['start_time_utc'], float) \
                            and np.isnan(package_data[routeID][sequence[index+1]][pkg]['time_window']['start_time_utc'])):
                        has_time_window = True
                        tw_start = dt.datetime.strptime(package_data[routeID][sequence[index+1]][pkg]['time_window']
                                                        ['start_time_utc'], '%Y-%m-%d %H:%M:%S')
                        tw_end = dt.datetime.strptime(package_data[routeID][sequence[index+1]][pkg]['time_window']
                                                      ['end_time_utc'], '%Y-%m-%d %H:%M:%S')
                    # I am considering that if depth_cm exists, than height_cm and width_cm also exist.
                    if not (isinstance(package_data[routeID][sequence[index+1]][pkg]['dimensions']['depth_cm'], float) \
                            and np.isnan(package_data[routeID][sequence[index+1]][pkg]['dimensions']['depth_cm'])):
                        # package volume
                        package_volume_stop += (package_data[routeID][sequence[index+1]][pkg]['dimensions']['depth_cm']
                                                * package_data[routeID][sequence[index+1]][pkg]['dimensions']['height_cm']
                                                * package_data[routeID][sequence[index+1]][pkg]['dimensions']['width_cm'])

                # route total delivery time (packages)
                delivery_time += service_time

                # package volume per route
                package_volume += package_volume_stop

                # check time window for each stop:
                if has_time_window:
                    # counting total number of packages with time window violation
                    package_count_violation += packages_per_stop
                    # time window for all stops (total em seconds)
                    tw_total += (tw_end - tw_start).total_seconds()
                    current_time = start_time + datetime.timedelta(seconds=(travel_time + delivery_time))
                    # if current time is not in the window, mark as a violation
                    if not (tw_start <= current_time <= tw_end):
                        tw_violated += 1
                        if current_time < tw_start:
                            tw_violated_early += 1
                            difference += (tw_start - current_time).total_seconds()
                            difference_early += (tw_start - current_time).total_seconds()
                        else:  # current_time > tw_end
                            # counting total number of packages with late time window violation
                            package_count_late_violation += packages_per_stop
                            # total volume of packages with late time window violation
                            package_volume_late_violation += package_volume_stop
                            tw_violated_late += 1
                            difference += (current_time - tw_end).total_seconds()
                            difference_late += (current_time - tw_end).total_seconds()

                # get data about zones
                zone_id = route['stops'][sequence[index + 1]]['zone_id']
                # backtracking: zone_id is in the sequence of zones visited, but it was not the last one
                if zone_id in zones:
                    if zone_id != zones[len(zones)-1]:
                        backtracking += 1
                else:  # zone_id was never visited before
                    unique_zones += 1
                zones.append(zone_id)

            # total delivery time = travel_time + delivery_time
            total_delivery_time = travel_time + delivery_time
            # total_delivery_time: route total time (distance + time for package delivery)
            features['total_delivery_time'] = total_delivery_time
            # travel_time: time to travel between stops (distance)
            features['travel_time'] = travel_time

            # violation_count: window violation count
            features['violation_count'] = tw_violated
            # violation_total_time: window violation total time (em seconds)
            features['violation_total_time'] = difference
            # violation_avg_time: window violation average time (em seconds)
            if tw_violated != 0:
                features['violation_avg_time'] = difference/tw_violated
            else:
                features['violation_avg_time'] = 0
            # ratio_violation: ratio between window violation time and window total time
            if tw_total != 0:
                features['ratio_violation'] = difference/tw_total
            else:
                features['ratio_violation'] = 0
            # violation_early_total_time: window violation total time - arrived early (time in seconds)
            features['violation_early_total_time'] = difference_early
            # violation_late_total_time: window violation total time - arrived late (time in seconds)
            features['violation_late_total_time'] = difference_late
            # violation_early_count:  window violation count - arrived early
            features['violation_early_count'] = tw_violated_early
            # violation_late_count: window violation time - arrived late
            features['violation_late_count'] = tw_violated_late
            # violation_early_avg_time: window violation avg time - arrived early (time in seconds)
            if tw_violated_early != 0:
                features['violation_early_avg_time'] = difference_early / tw_violated_early
            else:
                features['violation_early_avg_time'] = 0
            # violation_late_avg_time: window violation avg time - arrived late (time in seconds)
            if tw_violated_late != 0:
                features['violation_late_avg_time'] = difference_late / tw_violated_late
            else:
                features['violation_late_avg_time'] = 0
            # ratio_early_violation: ratio between window violation time and window total time - arrived early
            # ratio_late_violation: ratio between window violation time and window total time - arrived late
            if tw_total != 0:
                features['ratio_early_violation'] = difference_early/tw_total
                features['ratio_late_violation'] = difference_late / tw_total
            else:
                features['ratio_early_violation'] = 0
                features['ratio_late_violation'] = 0

            # ratio_delivery_time_stops: ratio between delivery time and number of stops
            features['ratio_delivery_time_stops'] = total_delivery_time/route_size
            # ratio_zones_delivery_time: ratio between number of unique zones and delivery time
            features['ratio_zones_delivery_time'] = unique_zones/total_delivery_time
            # ratio_route_size_delivery_time: ratio between route size (number of stops) and delivery time
            features['ratio_route_size_delivery_time'] = route_size/total_delivery_time
            # ratio_packages_count_delivery_time: ratio between number of packages and delivery time
            features['ratio_packages_count_delivery_time'] = package_count/total_delivery_time
            # ratio_violation_delivery_time: ratio between window violation count and delivery time (route size)
            features['ratio_violation_delivery_time'] = tw_violated/total_delivery_time
            # ratio_delivery_time_stops: ratio between delivery time and number of stops (route size)
            features['ratio_delivery_time_stops'] = total_delivery_time/route_size
            # ratio_delivery_time_packages_count: ratio between delivery time and number of packages
            features['ratio_delivery_time_packages_count'] = total_delivery_time/package_count

            # zones_count: number of unique zones per route
            features['zones_count'] = unique_zones
            # backtracking_count: backtracking count (number of times a driver leaves and then goes back to a zone)
            features['backtracking_count'] = backtracking
            # ratio_backtracking_route_size: ratio between backtracking count and route size
            features['ratio_backtracking_route_size'] = backtracking/len(sequence)
            # ration_backtracking_route_zones: ratio between backtracking count and number of unique zones in a route
            features['ratio_backtracking_route_zones'] = backtracking/unique_zones
            # ratio_zones_route_size: ratio between number of unique zones and route size (number of stops per route)
            features['ratio_zones_route_size'] = unique_zones/route_size
            # ratio_zones_travel_time: ratio between number of unique zones and travel time
            features['ratio_zones_travel_time'] = unique_zones/travel_time
            # ratio_route_size_travel_time: ratio between route size (number of stops) and travel time
            features['ratio_route_size_travel_time'] = route_size/travel_time

            # ratio_packages_count_travel_time: ratio between number of packages and total travel_time
            features['ratio_packages_count_travel_time'] = package_count/travel_time
            # ratio_packages_count_route_size: ratio between number of packages and route size (number of stops)
            features['ratio_packages_count_travel_time'] = package_count/route_size
            # ratio_violation_travel_time: ratio between window violation count and travel time
            features['ratio_violation_travel_time'] = tw_violated/travel_time
            # ratio_travel_time_stops: ratio between travel time and number of stops (route size)
            features['ratio_travel_time_stops'] = travel_time/route_size
            # ratio_travel_time_packages_count: ratio between travel time and number of packages
            features['ratio_travel_time_packages_count'] =  travel_time/package_count
            # ratio_package_count_violation_avg_time: ratio between average number of packages (not delivered on time)
            # and window violation average time
            if tw_violated != 0:
                features['ratio_package_count_violation_avg_time'] = (package_count_violation/tw_violated)/(difference/tw_violated)
            else:
                features['ratio_package_count_violation_avg_time'] = 0
            # ratio_package_count_violation_total_time: ratio between packages count (not delivered on time) and window
            # violation total time
            if tw_violated != 0:
                features['ratio_package_count_violation_total_time'] = package_count_violation/difference
            else:
                features['ratio_package_count_violation_total_time'] = 0
            # ratio_package_count_violation_late_avg_time: ratio between avg packages count (delivered late) and window
            # violation (late) average time
            if difference_late != 0:
                features['ratio_package_count_violation_late_avg_time'] = (package_count_late_violation /
                                                                           tw_violated_late)/(difference_late /
                                                                                              tw_violated_late)
            else:
                features['ratio_package_count_violation_late_avg_time'] = 0
            # ratio_package_count_violation_late_total_time: ration between total packages count (delivered late) and
            # window violation (late) total time
            if difference_late != 0:
                features['ratio_package_count_violation_late_total_time'] = package_count_late_violation/difference_late
            else:
                features['ratio_package_count_violation_late_total_time'] = 0
            # ratio_package_volume_delivery_time: ratio between packages volume and total delivery time
            features['ratio_package_volume_delivery_time'] = package_volume/total_delivery_time
            # ratio_package_volume_violation_time: ratio between packages volume (not delivered on time) and window violation
            #         total time
            if tw_violated != 0:
                features['ratio_package_volume_violation_time'] = package_volume_late_violation/difference
            else:
                features['ratio_package_volume_violation_time'] = 0
            # ratio_package_volume_violation_late_total_time: ratio between packages (not delivered on time) volume and
            # window violation (late) total time
            if difference_late != 0:
                features['ratio_package_volume_violation_late_total_time'] = package_volume_late_violation/difference_late
            else:
                features['ratio_package_volume_violation_late_total_time'] = 0

            rush_hour = [(datetime.time(7), datetime.time(9)), (datetime.time(17), datetime.time(19))]
            # rush_hour_morning (7am-9am)
            end_route = start_time + datetime.timedelta(seconds=total_delivery_time)
            features['rush_hour_morning'] = self.time_in_between(rush_hour=rush_hour[0], start_route=start_time.time(),
                                                                 end_route=end_route.time())
            # rush_hour_evening (5pm-7pm)
            features['rush_hour_evening'] = self.time_in_between(rush_hour=rush_hour[1], start_route=start_time.time(),
                                                                 end_route=end_route.time())

            if self.phase == 'build':
                # label: route_score (HIGH, MEDIUM, LOW)
                features['route_score'] = route['route_score']
            all_features.append(features)

        # TODO: Features and labels can be return to feed the classifier.
        # For now, I am saving them in a file called features.json
        # return all_features

        # only for test
        with open(self.features_file, "w") as feature_file:
            # Serializing json
            json_object = json.dumps(all_features)
            # Writing features into a file, only for test
            feature_file.write(json_object)


def main():
    """
    For now, I am considering the following structure for the data:
    Model Build
        data/model_build_inputs
        data/model_build_output
    Model Apply:
        data/model_apply_inputs
        data/model_apply_outputs
    """
    if len(sys.argv) != 2:
        return 'python3 feature_engineering.py [build or apply]'
    if len(sys.argv) == 1 and (sys.argv[1] != 'build' or sys.argv[1] != 'apply'):
        return 'python3 feature_engineering.py [build or apply]'

    if sys.argv[1] == 'build':
        # model build: feature engineering
        fe = FeatureEngineering(phase='build', path_input='data/model_build_inputs/')
        fe.create_features()
    else:  # apply
        # model build: feature engineering
        fe = FeatureEngineering(phase='apply', path_input='data/model_apply_inputs/',
                                path_output='data/model_apply_outputs/')
        # def create_features(self, json_light = False):
        # "fe.create_features(True) to load routes individually, saving memory"

        fe.create_features()



if __name__ == '__main__':
    main()