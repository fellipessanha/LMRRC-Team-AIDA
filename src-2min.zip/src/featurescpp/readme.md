## Compiling this:
if you're on the root directory:

g++ -Isrc/libs -Ofast featurescpp/cpp_features_example.cpp -omodelofeatures
