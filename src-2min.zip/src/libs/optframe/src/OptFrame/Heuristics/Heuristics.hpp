#ifndef OPTFRAME_HEURISTICS_HPP
#define OPTFRAME_HEURISTICS_HPP

// Heuristics Module: inclusion of common heuristic strategies

#include "SA/BasicSimulatedAnnealing.hpp"

#endif // OPTFRAME_HEURISTICS_HPP