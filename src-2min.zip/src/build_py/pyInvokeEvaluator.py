
# working RouteID must be pre-loaded via 'loadRouteId'
routeId = ""

def loadRouteId(_routeId):
    x=1
    #_routeId = "{}"
    global routeId
    print('Python function loadRouteId() called')
    print('got routeId = ', _routeId, ' x = ', x)
    routeId = _routeId
    return 99 # OK


# execute model evaluation for route dictionary in json format
def modelEvaluator(routeJsonStr = ""):
    print('Python function modelEvaluator() called')
    print('got routeId = ', routeId)
    print('got routeJsonStr = ', routeJsonStr)
    high_medlow = 0
    return high_medlow