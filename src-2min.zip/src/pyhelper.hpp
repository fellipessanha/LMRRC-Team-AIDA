// FROM: https://www.codeproject.com/Articles/820116/Embedding-Python-program-in-a-C-Cplusplus-code

#ifndef PYHELPER_HPP
#define PYHELPER_HPP
#pragma once

#include <iostream>
#include <stdio.h>

//
#include <Python.h>

#include<filesystem>
#include<sstream>

// wstring stuff....
#include <locale>
#include <codecvt>
#include <string>

class CPyInstance
{
public:

   std::wstring widePath;

   CPyInstance()
   {
      std::string initPath = std::filesystem::current_path();
      std::cout << "current path: '" << initPath << "'" << std::endl;
      //
      std::stringstream ss;
      ss << "/usr/lib/python38.zip:/usr/lib/python3.8:/usr/lib/python3.8/lib-dynload:";
      //
      //ss << initPath.substr(1, initPath.length()-2); // remove crazy '\"' symbols! Why these????
      ss << initPath;
      std::string spath = ss.str();
      // force manual path
      //spath = "/usr/lib/python38.zip:/usr/lib/python3.8:/usr/lib/python3.8/lib-dynload:/home/imcoelho/git-reps/AmazonChallenge/src";
      //std::wstring ws = std::to_wstring(s.c_str());
      std::cout << "set path: '" << spath << "'" << std::endl;

      std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
      this->widePath = converter.from_bytes(spath);
      Py_SetPath(widePath.c_str());

      //std::string strpacks = "/usr/lib/python3/dist-packages";
      //std::wstring wide2 = converter.from_bytes(strpacks);
      //Py_SetPath(wide2.c_str());
      //
      Py_Initialize();

      // wchar_t* wpath_ptr = Py_GetPath();
      // std::wstring wpath = wpath_ptr;
      //std::string narrow = converter.to_bytes(wpath);
      //std::cout << "final path: " << narrow << std::endl;
      
   }

   ~CPyInstance()
   {
      // DONT EVEN TRY CALLING Py_Finalize().... IT WONT CLEAR YOUR MEMORY!
      // https://stackoverflow.com/questions/8798905/does-the-python-3-interpreter-leak-memory-when-embedded
      //
      //Py_Finalize();
   }
};

class CPyObject
{
private:
   PyObject* p;

public:
   CPyObject()
     : p(NULL)
   {}

   CPyObject(PyObject* _p)
     : p(_p)
   {}

   ~CPyObject()
   {
      Release();
   }

   PyObject* getObject()
   {
      return p;
   }

   PyObject* setObject(PyObject* _p)
   {
      return (p = _p);
   }

   PyObject* AddRef()
   {
      if (p) {
         Py_INCREF(p);
      }
      return p;
   }

   void Release()
   {
      if (p) {
         Py_DECREF(p);
      }

      p = NULL;
   }

   PyObject* operator->()
   {
      return p;
   }

   bool is()
   {
      return p ? true : false;
   }

   operator PyObject*()
   {
      return p;
   }

   PyObject* operator=(PyObject* pp)
   {
      p = pp;
      return p;
   }

   operator bool()
   {
      return p ? true : false;
   }
};

#endif